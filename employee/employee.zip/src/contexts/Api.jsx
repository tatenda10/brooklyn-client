const BASE_URL = 'http://localhost:5000/api';

export default BASE_URL;