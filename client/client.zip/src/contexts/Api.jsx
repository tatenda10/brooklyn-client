const BASE_URL = 'http://localhost:5000/api';
//const BASE_URL = 'http://143.110.143.234:5000/api';
export default BASE_URL;